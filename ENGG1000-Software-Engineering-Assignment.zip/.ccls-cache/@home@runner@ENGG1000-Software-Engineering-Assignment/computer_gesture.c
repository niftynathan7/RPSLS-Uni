#include <stdio.h>
#include <stdlib.h>
#include <time.h>
  
int computer_gesture;

void get_computer_gesture(){
  computer_gesture = rand() % 3;
}