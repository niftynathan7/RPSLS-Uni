#include <cs50.h>
#include <stdio.h>

string computer_choice(int computergesture){
  if(computergesture == 0){
    return "Rock";
  }
  else if(computergesture == 1){
    return "Paper";
  }
  else if(computergesture == 2){
    return "Scissors";
  }
  else if(computergesture == 3){
    return "Lizard";
  }
  else if(computergesture == 4){
    return "Spock";
  }
  else{
    return "Error";
  }
}