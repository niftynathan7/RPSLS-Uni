#include <stdio.h>
#include <cs50.h>

string end(s){
  printf("The Final Score was: %i\n",finalscore);
  return 0;
}