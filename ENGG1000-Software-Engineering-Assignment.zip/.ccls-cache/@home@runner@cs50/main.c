#include <stdio.h>
#include <cs50.h>

int main(void) {
  
	int a = get_int("Enter an integer: ");
	printf("You entered: %d\n", a);


	char *str = get_string("farts: ");
		
  return 0;
}