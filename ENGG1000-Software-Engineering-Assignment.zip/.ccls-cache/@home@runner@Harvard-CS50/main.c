#include <stdio.h>
#include <cs50.h>

int main(void) {
  
	int a = get_int("Enter an integer: ");
	printf("You entered: %d\n", a);
	
  return 0;
}